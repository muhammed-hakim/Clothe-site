import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { X, MoreVertical, MapPin, Phone, Mail, Save } from 'lucide-react';
import { mockOrders } from '../../lib/mockData';
import type { OrderStatus } from '../../types';

const STATUS_STEPS: OrderStatus[] = ['Pending', 'Processing', 'Shipped', 'Delivered'];

const STATUS_OPTIONS: OrderStatus[] = [
  'Pending', 'Confirmed', 'Processing', 'Shipped', 'Delivered', 'Cancelled'
];

export default function OrderDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const order = mockOrders.find((o) => o.id === id) ?? mockOrders[0];
  const [status, setStatus] = useState<OrderStatus>(order.status);
  const [note, setNote] = useState(
    order.internalNote ?? 'Customer requested signature rose-scented packaging and a handwritten gift note for \'Happy Birthday!\' Ensure double-checking the...'
  );
  const [tracking, setTracking] = useState(order.trackingNumber ?? '');

  const currentStepIdx = STATUS_STEPS.indexOf(status as any);

  const getStatusClass = (s: string) => {
    const map: Record<string, string> = {
      Shipped: 'badge-shipped', Delivered: 'badge-delivered',
      Pending: 'badge-pending', Confirmed: 'badge-confirmed',
      Processing: 'badge-processing', Cancelled: 'badge-cancelled',
    };
    return map[s] ?? 'badge-pending';
  };

  const formatPrice = (n: number) =>
    new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 2 }).format(n);

  return (
    <div className="min-h-screen bg-ivory max-w-[430px] mx-auto pb-24">
      {/* Header */}
      <div className="sticky top-0 z-30 bg-white border-b border-gray-100 px-4 py-3 flex items-center justify-between">
        <button onClick={() => navigate(-1)} className="p-1">
          <X size={20} className="text-charcoal" />
        </button>
        <div className="text-center">
          <p className="text-[10px] tracking-widest uppercase text-soft-gray">Order Summary</p>
          <div className="flex items-center gap-2">
            <span className="font-inter font-bold text-sm text-charcoal">{order.orderNumber}</span>
            <span className={`badge text-[10px] ${getStatusClass(order.status)}`}>
              {order.status.toUpperCase()}
            </span>
          </div>
        </div>
        <button className="p-1">
          <MoreVertical size={20} className="text-soft-gray" />
        </button>
      </div>

      <div className="px-4 pt-4 space-y-4">
        {/* Action Buttons */}
        <div className="flex gap-2">
          <button className="btn-ghost text-xs px-4 py-2.5 flex-1">PRINT INVOICE</button>
          <button className="btn-primary text-xs px-4 py-2.5 flex-1">UPDATE STATUS</button>
        </div>

        {/* Fulfillment Progress */}
        <div className="bg-white rounded-card shadow-card p-5">
          <h3 className="font-playfair text-lg font-semibold text-charcoal mb-4">
            Fulfillment Progress
          </h3>
          <div className="flex items-center">
            {STATUS_STEPS.map((step, idx) => (
              <div key={step} className="flex items-center flex-1 last:flex-none">
                {/* Circle */}
                <div className="flex flex-col items-center gap-1">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium transition-all ${
                    idx <= currentStepIdx
                      ? 'bg-rose-dark text-white'
                      : 'bg-gray-100 text-soft-gray'
                  }`}>
                    {idx < currentStepIdx ? '✓' : idx + 1}
                  </div>
                  <span className="text-[9px] tracking-wider uppercase text-soft-gray whitespace-nowrap">
                    {step}
                  </span>
                </div>
                {/* Line */}
                {idx < STATUS_STEPS.length - 1 && (
                  <div className={`flex-1 h-px mx-1 mb-4 ${
                    idx < currentStepIdx ? 'bg-rose-dark' : 'bg-gray-200'
                  }`} />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Ordered Pieces */}
        <div className="bg-white rounded-card shadow-card p-5">
          <h3 className="font-playfair text-lg font-semibold text-charcoal mb-4">
            Ordered Pieces
          </h3>
          <div className="space-y-4">
            {order.items.map((item, i) => (
              <div key={i} className="flex gap-3 pb-4 border-b border-gray-50 last:border-0 last:pb-0">
                <div className="w-14 h-16 rounded-xl overflow-hidden bg-cream flex-shrink-0">
                  <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                </div>
                <div className="flex-1">
                  <p className="font-inter font-medium text-sm text-charcoal mb-0.5">{item.name}</p>
                  <p className="text-xs text-soft-gray mb-2">
                    SIZE: {item.size} &nbsp;·&nbsp; COLOR: {item.color.toUpperCase()}
                  </p>
                  <div className="flex items-center justify-between">
                    <p className="text-[10px] tracking-widest uppercase text-soft-gray">PRICE</p>
                    <p className="font-inter font-semibold text-charcoal text-sm">
                      {formatPrice(item.unitPrice)}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Internal Notes */}
        <div className="bg-white rounded-card shadow-card p-5">
          <h3 className="font-playfair text-lg font-semibold text-charcoal mb-3">
            Atelier Internal Notes
          </h3>
          <textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            rows={4}
            className="w-full bg-cream rounded-xl p-3 text-sm text-soft-gray italic font-cormorant outline-none resize-none focus:ring-2 focus:ring-rose-primary/20"
            placeholder="Add private notes about customer preferences, sizes, or special requests..."
          />
          <div className="flex items-center justify-between mt-2">
            <p className="text-[10px] text-soft-gray">Last edited by Admin, 1 day ago</p>
            <button className="flex items-center gap-1 text-xs text-rose-dark font-medium">
              <Save size={12} /> SAVE NOTE
            </button>
          </div>
        </div>

        {/* Customer Info */}
        <div className="bg-white rounded-card shadow-card p-5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-full overflow-hidden bg-rose-light">
              <img
                src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=80&q=80"
                alt={order.customerName}
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <p className="font-inter font-semibold text-sm text-charcoal">{order.customerName}</p>
              <p className="text-[10px] tracking-widest uppercase text-rose-dark font-medium">VIP CLIENT</p>
            </div>
          </div>
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm text-soft-gray">
              <Mail size={14} className="text-rose-dark" />
              <span>{order.customerEmail}</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-soft-gray">
              <Phone size={14} className="text-rose-dark" />
              <span>{order.customerPhone}</span>
            </div>
          </div>
        </div>

        {/* Delivery Address */}
        <div className="bg-white rounded-card shadow-card p-5">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-playfair text-lg font-semibold text-charcoal">Delivery Address</h3>
            <MapPin size={16} className="text-soft-gray" />
          </div>
          <p className="text-sm text-charcoal">{order.deliveryAddress.street}</p>
          <p className="text-sm text-soft-gray">{order.deliveryAddress.city}, {order.deliveryAddress.postalCode}</p>
          <p className="text-sm text-soft-gray">{order.deliveryAddress.country}</p>

          {/* Mini map placeholder */}
          <div className="mt-3 h-24 bg-cream rounded-xl overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1524813686514-a57563d77965?w=300&q=80"
              alt="Map"
              className="w-full h-full object-cover opacity-60"
            />
          </div>
        </div>

        {/* Order Value */}
        <div className="rounded-card overflow-hidden">
          <div className="admin-header-dark px-5 py-4">
            <h3 className="font-playfair text-lg font-semibold text-white mb-3">Order Value</h3>
            <div className="space-y-2">
              <div className="flex justify-between text-sm text-white/70">
                <span>SUBTOTAL</span>
                <span>{formatPrice(order.subtotal)}</span>
              </div>
              <div className="flex justify-between text-sm text-white/70">
                <span>SHIPPING</span>
                <span className="text-rose-primary">
                  {order.shipping === 0 ? 'Complimentary' : formatPrice(order.shipping)}
                </span>
              </div>
              <div className="flex justify-between text-sm text-white/70">
                <span>LUXURY VAT (18%)</span>
                <span>{formatPrice(order.subtotal * 0.18)}</span>
              </div>
              <div className="flex justify-between font-bold text-white text-base pt-2 border-t border-white/20">
                <span>TOTAL AMOUNT</span>
                <span>{formatPrice(order.total + order.subtotal * 0.18)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Tracking */}
        <div className="bg-white rounded-card shadow-card p-5">
          <p className="text-[10px] tracking-widest uppercase text-soft-gray mb-1">LOGISTICS DETAIL</p>
          <input
            value={tracking}
            onChange={(e) => setTracking(e.target.value)}
            placeholder="Add tracking number..."
            className="input-field mt-2"
          />
        </div>
      </div>

      {/* Admin Bottom Nav */}
      <div className="fixed bottom-0 left-0 right-0 max-w-[430px] mx-auto bg-white border-t border-gray-100 z-20">
        <div className="flex items-center justify-around py-2">
          {[
            { label: 'Orders', icon: '🛍', href: '/admin/orders', active: true },
            { label: 'Customers', icon: '👥', href: '/admin/customers' },
            { label: 'Inventory', icon: '📦', href: '/admin/products' },
            { label: 'Analytics', icon: '📊', href: '/admin/stats' },
          ].map((item) => (
            <a
              key={item.label}
              href={item.href}
              className={`flex flex-col items-center gap-0.5 px-3 py-1 ${
                item.active ? 'text-rose-dark' : 'text-soft-gray'
              }`}
            >
              <span className="text-lg">{item.icon}</span>
              <span className="text-[9px] tracking-wider uppercase">{item.label}</span>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}
