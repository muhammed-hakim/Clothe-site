import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from './store';

// Layout
import Navbar from './components/common/Navbar';
import CartDrawer from './components/common/CartDrawer';

// Customer Pages
import HomePage from './pages/customer/HomePage';
import ShopPage from './pages/customer/ShopPage';
import ProductDetailPage from './pages/customer/ProductDetailPage';
import CheckoutPage from './pages/customer/CheckoutPage';
import OrderConfirmationPage from './pages/customer/OrderConfirmationPage';
import { LoginPage, RegisterPage } from './pages/customer/AuthPages';
import { AccountPage, ContactPage, WishlistPage } from './pages/customer/CustomerPages';
import ProfilePage from './pages/customer/ProfilePage';
import RecentlyViewedPage from './pages/customer/RecentlyViewedPage';
import AboutPage from './pages/customer/AboutPage';

// Admin Pages
import AdminLogin from './pages/admin/AdminLogin';
import OrderDetailPage from './pages/admin/OrderDetailPage';
import {
  AdminDashboard,
  AdminOrders,
  AdminProducts,
  AdminCustomers,
  AdminStatistics,
  AdminCategories,
} from './pages/admin/AdminPages';

// ===== Protected Route =====
function ProtectedRoute({ children, adminOnly = false }: { children: React.ReactNode; adminOnly?: boolean }) {
  const { isAuthenticated, user } = useAuthStore();
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  if (adminOnly && user?.role !== 'Admin') return <Navigate to="/" replace />;
  return <>{children}</>;
}

// ===== Customer Layout =====
function CustomerLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="max-w-[430px] mx-auto bg-ivory min-h-screen relative">
      <Navbar />
      <main>{children}</main>
      <CartDrawer />
    </div>
  );
}

// ===== App =====
export default function App() {
  return (
    <BrowserRouter>
      <Routes>

        {/* ===== CUSTOMER ROUTES ===== */}
        <Route path="/" element={
          <CustomerLayout>
            <HomePage />
          </CustomerLayout>
        } />

        <Route path="/shop" element={
          <CustomerLayout>
            <ShopPage />
          </CustomerLayout>
        } />

        <Route path="/product/:id" element={
          <CustomerLayout>
            <ProductDetailPage />
          </CustomerLayout>
        } />

        <Route path="/checkout" element={
          <CustomerLayout>
            <CheckoutPage />
          </CustomerLayout>
        } />

        <Route path="/order-confirmation/:id" element={
          <CustomerLayout>
            <OrderConfirmationPage />
          </CustomerLayout>
        } />

        <Route path="/wishlist" element={
          <CustomerLayout>
            <WishlistPage />
          </CustomerLayout>
        } />

        <Route path="/recently-viewed" element={
          <CustomerLayout>
            <RecentlyViewedPage />
          </CustomerLayout>
        } />

        <Route path="/contact" element={
          <CustomerLayout>
            <ContactPage />
          </CustomerLayout>
        } />

        <Route path="/about" element={
          <CustomerLayout>
            <AboutPage />
          </CustomerLayout>
        } />

        {/* Auth - no navbar needed for these */}
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />

        {/* Protected Customer */}
        <Route path="/account" element={
          <ProtectedRoute>
            <CustomerLayout>
              <AccountPage />
            </CustomerLayout>
          </ProtectedRoute>
        } />

        <Route path="/profile" element={
          <ProtectedRoute>
            <CustomerLayout>
              <ProfilePage />
            </CustomerLayout>
          </ProtectedRoute>
        } />

        {/* ===== ADMIN ROUTES ===== */}
        <Route path="/admin/login" element={<AdminLogin />} />

        <Route path="/admin" element={
          <ProtectedRoute adminOnly>
            <AdminDashboard />
          </ProtectedRoute>
        } />

        <Route path="/admin/orders" element={
          <ProtectedRoute adminOnly>
            <AdminOrders />
          </ProtectedRoute>
        } />

        <Route path="/admin/orders/:id" element={
          <ProtectedRoute adminOnly>
            <OrderDetailPage />
          </ProtectedRoute>
        } />

        <Route path="/admin/products" element={
          <ProtectedRoute adminOnly>
            <AdminProducts />
          </ProtectedRoute>
        } />

        <Route path="/admin/categories" element={
          <ProtectedRoute adminOnly>
            <AdminCategories />
          </ProtectedRoute>
        } />

        <Route path="/admin/customers" element={
          <ProtectedRoute adminOnly>
            <AdminCustomers />
          </ProtectedRoute>
        } />

        <Route path="/admin/stats" element={
          <ProtectedRoute adminOnly>
            <AdminStatistics />
          </ProtectedRoute>
        } />

        {/* 404 Fallback */}
        <Route path="*" element={
          <CustomerLayout>
            <div className="flex flex-col items-center justify-center min-h-[60vh] px-4 text-center">
              <p className="font-playfair text-6xl font-bold text-rose-primary mb-4">404</p>
              <h1 className="font-playfair text-2xl font-semibold text-charcoal mb-2">
                Page Not Found
              </h1>
              <p className="text-soft-gray text-sm mb-8 font-cormorant italic">
                This piece is no longer in our collection.
              </p>
              <a href="/" className="btn-primary text-xs px-8 py-3">
                RETURN TO ATELIER
              </a>
            </div>
          </CustomerLayout>
        } />

      </Routes>
    </BrowserRouter>
  );
}
