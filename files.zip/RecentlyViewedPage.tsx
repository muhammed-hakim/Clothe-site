import { ArrowLeft, ShoppingBag } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { recentlyViewedProducts } from '../../lib/mockData';

export default function RecentlyViewedPage() {
  const navigate = useNavigate();

  const moreFromCollection = [
    { name: 'Gold Accent Belt', price: '₺1,450', category: 'ESSENTIAL ACCENTS', image: 'https://images.unsplash.com/photo-1589556264800-08ae9e129a8e?w=80&q=80' },
    { name: 'Breeze Linen Trousers', price: '₺3,100', category: 'CONTEMPORARY FIT', image: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=80&q=80' },
    { name: 'Pearl Evening Stiletto', price: '₺4,800', category: 'EVENING RADIANCE', image: 'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=80&q=80' },
  ];

  return (
    <div className="pb-20">
      {/* Header */}
      <div className="flex items-center justify-between px-4 pt-4 pb-2">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-1.5 text-charcoal"
        >
          <ArrowLeft size={18} />
          <span className="text-xs font-bold tracking-widest uppercase">AURA DE NİŞANTAŞI</span>
        </button>
        <button className="relative">
          <ShoppingBag size={20} className="text-charcoal" />
        </button>
      </div>

      {/* Title */}
      <div className="px-4 pt-4 pb-2">
        <p className="font-inter text-[10px] tracking-widest uppercase text-soft-gray mb-1">
          CURATED SELECTION
        </p>
        <h1 className="font-playfair text-3xl font-bold text-charcoal">Recently Viewed</h1>
        <p className="font-cormorant italic text-soft-gray text-sm mt-1">
          Your style journey continues
        </p>
      </div>

      {/* Clear All */}
      <div className="px-4 mb-4 flex justify-end">
        <button className="text-xs text-soft-gray hover:text-charcoal tracking-widest uppercase flex items-center gap-1">
          CLEAR ALL ↑
        </button>
      </div>

      {/* Products Grid — 2 columns */}
      <div className="px-4 grid grid-cols-2 gap-3 mb-6">
        {recentlyViewedProducts.map((item) => (
          <div
            key={item.productId}
            className="bg-white rounded-card shadow-card overflow-hidden"
          >
            <div className="aspect-square bg-cream overflow-hidden">
              <img
                src={item.image}
                alt={item.name}
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
              />
            </div>
            <div className="p-3">
              {/* Badge */}
              {item.badge && (
                <p className="text-[9px] font-medium tracking-widest uppercase text-soft-gray mb-1">
                  {item.badge}
                </p>
              )}
              <h3 className="font-playfair text-sm font-semibold text-charcoal mb-1 leading-snug">
                {item.name}
              </h3>
              <p className="font-inter font-semibold text-charcoal text-sm mb-2">
                ₺{item.price.toLocaleString()}
              </p>
              <button className="btn-primary w-full text-[10px] py-2 tracking-widest">
                ADD TO BAG
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Atelier Philosophy */}
      <div className="mx-4 mb-6 rounded-card overflow-hidden">
        <div className="h-48 bg-cream overflow-hidden">
          <img
            src="https://images.unsplash.com/photo-1558769132-cb1aea458c5e?w=400&q=80"
            alt="Atelier"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="bg-cream px-5 pt-5 pb-6">
          <p className="text-[10px] font-bold tracking-widest uppercase text-soft-gray mb-3">
            THE ATELIER PHILOSOPHY
          </p>
          <p className="font-cormorant italic text-xl text-charcoal leading-relaxed mb-3">
            "Luxury is not about visibility; it is about the feeling of silk against skin as you walk along the Bosphorus at dawn."
          </p>
          <p className="text-xs text-soft-gray leading-relaxed">
            Every piece at Aura de Nişantaşı is a testament to the artisan's hand and the soul of Istanbul.
          </p>
        </div>
      </div>

      {/* More From The Collection */}
      <div className="px-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="font-playfair text-xl font-semibold text-charcoal">
              More From The Collection
            </h2>
            <p className="text-[10px] tracking-widest uppercase text-soft-gray mt-0.5">
              CURATED ESSENTIALS
            </p>
          </div>
          <button className="text-xs text-rose-dark font-medium tracking-widest uppercase">
            EXPLORE ALL
          </button>
        </div>

        <div className="space-y-0 divide-y divide-gray-100">
          {moreFromCollection.map((item, i) => (
            <div key={i} className="flex items-center gap-4 py-4">
              <div className="w-14 h-14 rounded-xl overflow-hidden bg-cream flex-shrink-0">
                <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
              </div>
              <div className="flex-1">
                <p className="text-[10px] tracking-widest uppercase text-soft-gray mb-0.5">
                  {item.category}
                </p>
                <p className="font-inter font-medium text-sm text-charcoal">{item.name}</p>
                <p className="font-inter font-semibold text-charcoal text-sm mt-0.5">{item.price}</p>
              </div>
              <button className="text-xs text-rose-dark font-medium tracking-widest uppercase">
                DISCOVER
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Nav */}
      <div className="fixed bottom-0 left-0 right-0 max-w-[430px] mx-auto bg-white border-t border-gray-100 z-40">
        <div className="flex items-center justify-around py-2">
          {[
            { label: 'ATELIER', icon: '⌂', href: '/' },
            { label: 'COLLECTIONS', icon: '✦', href: '/shop' },
            { label: 'WISHLIST', icon: '♡', href: '/wishlist', active: true },
            { label: 'PROFILE', icon: '👤', href: '/account' },
          ].map((item) => (
            <a
              key={item.label}
              href={item.href}
              className={`flex flex-col items-center gap-0.5 px-3 py-1 ${
                item.active ? 'text-rose-dark' : 'text-soft-gray'
              }`}
            >
              <span className="text-lg">{item.icon}</span>
              <span className="text-[9px] tracking-wider uppercase">{item.label}</span>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}
