import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Eye, EyeOff, ShieldCheck } from 'lucide-react';
import { useAuthStore } from '../../store';

export default function AdminLogin() {
  const [email, setEmail] = useState('admin@ladyfashion.tr');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState('');
  const { login } = useAuthStore();
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (email === 'admin@ladyfashion.tr' && password === 'admin123') {
      login(
        {
          id: 'admin-1',
          fullName: 'Admin User',
          email,
          role: 'Admin',
          memberSince: '2022',
          isActive: true,
          isBlocked: false,
          totalSpent: 0,
          ordersCount: 0,
          avgOrderValue: 0,
          isVip: false,
        },
        'admin-token-secret'
      );
      navigate('/admin');
    } else {
      setError('Invalid credentials. Try admin@ladyfashion.tr / admin123');
    }
  };

  return (
    <div className="min-h-screen bg-ivory flex flex-col items-center justify-center px-4">
      {/* Logo */}
      <div className="mb-8 text-center">
        <p className="font-playfair text-2xl font-semibold text-charcoal tracking-wider mb-1">
          LADY FASHION
        </p>
        <p className="text-[10px] tracking-widest uppercase text-soft-gray">
          Atelier Admin Portal
        </p>
      </div>

      <div className="w-full max-w-sm">
        {/* Dark Header Card */}
        <div className="admin-header-dark rounded-t-card px-6 py-6 text-center">
          <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3">
            <ShieldCheck size={22} className="text-white" />
          </div>
          <h1 className="font-playfair text-xl font-semibold text-white mb-1">
            THE ATELIER ADMIN
          </h1>
          <p className="text-white/60 text-xs tracking-widest uppercase">
            Secure Access Portal
          </p>
        </div>

        {/* Form Card */}
        <div className="bg-white rounded-b-card shadow-card px-6 py-6">
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="input-label">EMAIL ADDRESS</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="input-field"
                required
              />
            </div>

            <div>
              <label className="input-label">PASSWORD</label>
              <div className="relative">
                <input
                  type={showPass ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="input-field pr-10"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-soft-gray"
                >
                  {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {error && (
              <p className="text-xs text-status-error bg-status-error/10 px-3 py-2 rounded-lg">
                {error}
              </p>
            )}

            <button
              type="submit"
              className="w-full py-4 text-sm font-medium tracking-widest uppercase text-white rounded-pill transition-all hover:opacity-90"
              style={{ background: 'linear-gradient(135deg, #6B2D3E 0%, #C4687E 100%)' }}
            >
              ENTER ATELIER
            </button>
          </form>

          {/* Hint */}
          <div className="mt-4 bg-cream rounded-xl p-3 text-center">
            <p className="text-[10px] text-soft-gray">
              Demo: <span className="font-medium text-charcoal">admin@ladyfashion.tr</span> / <span className="font-medium text-charcoal">admin123</span>
            </p>
          </div>

          <div className="flex items-center justify-center gap-1.5 mt-4">
            <ShieldCheck size={11} className="text-soft-gray" />
            <p className="text-[10px] text-soft-gray tracking-widest uppercase">
              Secure Encrypted Connection
            </p>
          </div>
        </div>
      </div>

      <p className="text-xs text-soft-gray mt-6 text-center">
        © 2024 LADY FASHION ATELIER. Admin System v2.1
      </p>
    </div>
  );
}
