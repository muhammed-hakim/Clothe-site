# 👗 LADY FASHION — Frontend Project

> **Aura de Nişantaşı** — A luxury women's fashion e-commerce storefront built with React + TypeScript + Tailwind CSS.

---

## 📋 Table of Contents

- [Overview](#overview)
- [Tech Stack](#tech-stack)
- [Design System](#design-system)
- [Project Structure](#project-structure)
- [Pages & Features](#pages--features)
- [State Management](#state-management)
- [Getting Started](#getting-started)
- [Environment Variables](#environment-variables)
- [API Integration](#api-integration)
- [Deployment](#deployment)

---

## Overview

**LADY FASHION** is a complete women's fashion e-commerce store based in Istanbul, Turkey. The project is split into two parts:

- 🛍️ **Customer Storefront** — Public shopping experience
- 🔧 **Admin Dashboard** — Store management portal (The Atelier Admin)

The design aesthetic is inspired by European luxury fashion boutiques, reflecting the Nişantaşı district of Istanbul — clean, feminine, elegant, and modern.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Framework | React 18 + TypeScript |
| Routing | React Router DOM v6 |
| Styling | Tailwind CSS v3 |
| State Management | Zustand (with persist middleware) |
| Data Fetching | TanStack React Query v5 |
| Form Handling | React Hook Form + Zod |
| Charts | Recharts |
| Icons | Lucide React |
| Notifications | React Hot Toast |
| Build Tool | Vite |

---

## Design System

### 🎨 Color Palette — *Aura de Nişantaşı*

#### Primary Colors
| Name | Hex | Usage |
|---|---|---|
| Rose Pink (Primary) | `#E8A0B4` | CTA buttons, highlights, accents |
| Deep Rose (Dark) | `#C4687E` | Hover states, active elements |
| Blush Pink (Light) | `#F7D6DF` | Backgrounds, cards, soft sections |

#### Neutral Colors
| Name | Hex | Usage |
|---|---|---|
| Ivory White | `#FAF7F5` | Main page background |
| Warm Cream | `#F5EFE6` | Section backgrounds, inputs |
| Charcoal | `#2C2C2C` | Primary text, headings |
| Soft Gray | `#8A8A8A` | Secondary text, placeholders |

#### Accent Colors
| Name | Hex | Usage |
|---|---|---|
| Gold | `#C9A84C` | Sale badges, star ratings, luxury accents |
| Dusty Mauve | `#B08A9E` | Decorative elements, category tags |

#### Status Colors
| Status | Hex |
|---|---|
| Success | `#7BAF7B` |
| Warning | `#E8C46A` |
| Error | `#D4726A` |
| Info | `#7AA3C4` |

---

### 🔤 Typography

| Role | Font | Size | Weight |
|---|---|---|---|
| Logo / Hero Headings | Playfair Display | 52px | Bold 700 |
| Section Titles | Playfair Display | 32px | SemiBold 600 |
| Product Names | Inter | 18px | Medium 500 |
| Body Text | Inter | 15px | Regular 400 |
| Labels / Badges | Inter | 12px | Medium 500, uppercase |
| Price | Inter | 20px | SemiBold 600 |
| Quotes / Taglines | Cormorant Garamond | Variable | Italic |

---

### 📐 Layout & Spacing

```
Max Container Width : 1280px (centered)
Base Spacing Unit   : 8px
Mobile Max Width    : 430px (mobile-first design)

Border Radius:
  Buttons  → 50px  (pill shape)
  Cards    → 16px
  Inputs   → 12px
  Badges   → 999px

Box Shadow:
  Card       → 0 4px 20px rgba(232, 160, 180, 0.15)
  Card Hover → 0 8px 32px rgba(232, 160, 180, 0.25)
```

---

### 📱 Responsive Breakpoints

| Breakpoint | Range |
|---|---|
| Mobile | 320px — 767px |
| Tablet | 768px — 1023px |
| Desktop | 1024px — 1279px |
| Large Desktop | 1280px+ |

---

## Project Structure

```
lady-fashion/
│
├── public/
│   └── favicon.ico
│
├── src/
│   ├── components/
│   │   ├── common/
│   │   │   ├── Navbar.tsx          # Sticky top nav + mobile drawer + bottom nav
│   │   │   ├── Footer.tsx          # Charcoal footer + Admin footer
│   │   │   ├── ProductCard.tsx     # Reusable product card + skeleton
│   │   │   └── CartDrawer.tsx      # "My Curation" slide-in cart
│   │   │
│   │   ├── customer/               # Customer-specific components
│   │   └── admin/                  # Admin-specific components
│   │
│   ├── pages/
│   │   ├── customer/
│   │   │   ├── HomePage.tsx            # Hero slider, categories, featured products
│   │   │   ├── ShopPage.tsx            # Product listing with filters & sort
│   │   │   ├── ProductDetailPage.tsx   # Gallery, size/color selector, add to cart
│   │   │   ├── CheckoutPage.tsx        # Multi-step delivery + payment
│   │   │   ├── OrderConfirmationPage.tsx
│   │   │   ├── AuthPages.tsx           # Login + Register
│   │   │   └── CustomerPages.tsx       # Account, Contact, Wishlist
│   │   │
│   │   └── admin/
│   │       └── AdminPages.tsx          # Dashboard, Orders, Products, Customers, Stats, Categories
│   │
│   ├── store/
│   │   └── index.ts            # Zustand stores: Cart, Auth, Wishlist
│   │
│   ├── types/
│   │   └── index.ts            # All TypeScript interfaces & types
│   │
│   ├── lib/
│   │   └── mockData.ts         # Mock data: products, categories, orders, users, stats
│   │
│   ├── styles/
│   │   └── globals.css         # Global CSS, custom classes, Tailwind layers
│   │
│   ├── App.tsx                 # Router configuration
│   └── main.tsx                # Entry point
│
├── tailwind.config.js          # Tailwind design tokens
├── vite.config.ts
├── tsconfig.json
└── package.json
```

---

## Pages & Features

### 🛍️ Customer Storefront (10 Pages)

#### 1. Homepage (`/`)
- ✅ Hero banner/slider (3 slides, auto-advance every 5s, fade transition)
- ✅ Browse the Atelier — Featured categories grid (2×2)
- ✅ Luxury Essentials — Horizontal scrollable featured products
- ✅ Promo banner — 20% OFF first curation
- ✅ New Arrivals section
- ✅ The Atelier Letter — Newsletter signup
- ✅ Footer

#### 2. Shop / Category Page (`/shop`)
- ✅ Breadcrumb navigation
- ✅ Page title + item count
- ✅ Filter by: Size, Color (bottom sheet drawer)
- ✅ Sort by: Newest, Price Low/High, Most Popular
- ✅ Active filter pills (removable)
- ✅ Product grid (single column, mobile-first)
- ✅ Load More button
- ✅ Loading skeletons

#### 3. Product Detail Page (`/product/:id`)
- ✅ Full-width product image gallery with thumbnail selector
- ✅ Wishlist heart button
- ✅ Badge (NEW ARRIVAL / SALE / LIMITED)
- ✅ Star rating display
- ✅ Color selector (color swatches)
- ✅ Size selector with out-of-stock indicator
- ✅ Low stock warning ("Only 2 left in size S")
- ✅ Designer's Note section (Cormorant Garamond italic)
- ✅ Accordion: Description, Size Guide, Shipping & Returns
- ✅ "Complete the Look" / Related Products
- ✅ Sticky "ADD TO BAG" bottom bar with wishlist button

#### 4. Cart Drawer (`/` — side panel)
- ✅ Slides in from right side
- ✅ "My Curation" header with item count
- ✅ Product thumbnail, name, color/size, quantity stepper, price
- ✅ Remove item button
- ✅ Complimentary Atelier Shipping badge
- ✅ Subtotal + Total
- ✅ PROCEED TO CHECKOUT button
- ✅ CONTINUE SHOPPING ghost button
- ✅ Secure Atelier Checkout badge

#### 5. Checkout Page (`/checkout`)
- ✅ 3-step progress indicator (Delivery → Payment → Review)
- ✅ Step 1: Delivery form (name, phone, email, address, city, postal code)
- ✅ Step 2: Payment card form (UI only, no real gateway)
- ✅ Order Summary sidebar with product thumbnails
- ✅ Atelier quote section
- ✅ PLACE ORDER button → redirects to confirmation
- ✅ Secure Atelier Encryption badge

#### 6. Order Confirmation Page (`/order-confirmation/:id`)
- ✅ Rose Pink checkmark success animation
- ✅ "A Moment of Celebration" heading
- ✅ Order ID (#AT-9025) + Estimated Arrival
- ✅ Ordered items list with images
- ✅ The Atelier Promise section (sustainable packaging)
- ✅ Delivery Address summary
- ✅ Financial Overview (subtotal + complimentary shipping + total)
- ✅ TRACK YOUR JOURNEY + RETURN TO ATELIER buttons
- ✅ Inspirational quote

#### 7. Login Page (`/login`)
- ✅ Centered card layout
- ✅ Email + Password inputs
- ✅ Show/hide password toggle
- ✅ Remember me checkbox
- ✅ Forgot password link
- ✅ Sign In button → mock authentication
- ✅ Link to Register

#### 8. Register Page (`/register`)
- ✅ Full Name + Email + Password + Confirm Password
- ✅ Show/hide password toggle
- ✅ Terms & Conditions checkbox
- ✅ Create Account button → mock registration
- ✅ Link to Login

#### 9. Account Page (`/account`)
- ✅ Welcome header with customer name
- ✅ Profile avatar + name + email
- ✅ EDIT PROFILE button
- ✅ Menu: My Orders, Wishlist, Settings
- ✅ Recent Acquisitions (order cards with image, status badge, actions)
- ✅ View Details + Track Order / Reorder Items buttons
- ✅ Load More Acquisitions
- ✅ Sign Out

#### 10. Contact Page (`/contact`)
- ✅ Rose Pink hero header
- ✅ Send an Inquiry form (name, email, subject, message)
- ✅ The Atelier store info (address, phone, email)
- ✅ Working Hours table
- ✅ Map placeholder with OPEN IN MAPS button
- ✅ Bespoke Tailoring section with BOOK A PRIVATE FITTING

#### 11. Wishlist Page (`/wishlist`)
- ✅ "My Curation" personal selection
- ✅ Wishlist items with images, badge, price, ADD TO BAG
- ✅ Remove item button
- ✅ Recommended for You section

---

### 🔧 Admin Dashboard (6+ Pages)

All admin pages share the **AdminLayout** with:
- Dark header (Deep Rose gradient `#6B2D3E → #4A1F2E`)
- Slide-in sidebar navigation
- Bell notification icon
- Bottom navigation bar

#### 1. Admin Dashboard (`/admin`)
- ✅ 4 stats cards: Revenue, Orders, Active Catalog, Total Customers
- ✅ Revenue Performance bar chart (Recharts)
- ✅ Atelier Alerts — Low stock warnings
- ✅ Recent Curations — Latest orders with customer avatars
- ✅ Admin Footer

#### 2. Order Curation (`/admin/orders`)
- ✅ 4 stats cards: Total Orders, Pending Fulfillment, Confirmed Today, Revenue MOM
- ✅ Tab filter: ALL / PENDING / CONFIRMED / SHIPPED / ARC
- ✅ Search bar
- ✅ Order cards with item thumbnail, customer, status badge, total
- ✅ Pagination

#### 3. Inventory Management (`/admin/products`)
- ✅ 4 stats: Total SKUs, Active Items, Low Stock, Out of Stock
- ✅ Search + Filter
- ✅ Product cards with image, name, category, price, stock status badge
- ✅ Active toggle switch (Rose Pink when ON)
- ✅ LOW STOCK / OUT OF STOCK / AVAILABLE color indicators
- ✅ Pagination (Previous / 1 2 3 / Next)

#### 4. Client Portfolio (`/admin/customers`)
- ✅ 3 stats: Total Customers, New This Month, Top Tier VIP
- ✅ Tab filter: ACTIVE / VIP / PROSPECTIVE / DORMANT
- ✅ Search bar
- ✅ Customer list with avatar, name, email, order count
- ✅ EXPORT LIST + INVITE MEMBER buttons

#### 5. Sales Statistics (`/admin/stats`)
- ✅ 3 stats cards with % growth badges: Revenue, Orders, AOV
- ✅ Revenue Growth line chart (Current + Projected Forecast)
- ✅ Curated Best Sellers list with images, units sold, rank
- ✅ Elite Clientele table (Patron, Orders, LTV)
- ✅ Inventory Insights — Low stock alerts with RESTOCK NOW / EXPRESS ORDER buttons

#### 6. Categories Management (`/admin/categories`)
- ✅ Search + ADD CATEGORY button
- ✅ Category cards with image, name, product count, active toggle
- ✅ Edit + Delete actions

---

## State Management

### Zustand Stores (persisted to localStorage)

#### 🛒 Cart Store (`useCartStore`)
```ts
items          : CartItem[]
isOpen         : boolean
addItem(item)          // adds or merges if same product+size+color
removeItem(id)
updateQuantity(id, qty)
clearCart()
openCart() / closeCart()
subtotal()     // computed total
itemCount()    // computed item count
```

#### 🔐 Auth Store (`useAuthStore`)
```ts
user           : User | null
token          : string | null
isAuthenticated: boolean
login(user, token)
logout()
updateUser(updates)
```

#### ❤️ Wishlist Store (`useWishlistStore`)
```ts
productIds     : string[]
toggle(productId)      // add or remove
isWishlisted(productId): boolean
```

---

## Getting Started

### Prerequisites
- Node.js 18+
- npm or yarn

### Installation

```bash
# 1. Clone the repository
git clone https://github.com/your-org/lady-fashion.git
cd lady-fashion

# 2. Install dependencies
npm install

# 3. Start the development server
npm run dev

# 4. Open in browser
# http://localhost:5173
```

### Build for Production

```bash
npm run build
npm run preview
```

---

## Environment Variables

Create a `.env` file in the root:

```env
# Backend API URL (ASP.NET Core)
VITE_API_URL=https://api.ladyfashion.tr/api

# Optional: Cloudinary or image CDN
VITE_IMAGE_CDN=https://res.cloudinary.com/your-cloud/image/upload
```

---

## API Integration

The frontend is pre-wired with mock data in `src/lib/mockData.ts`. To connect to the real ASP.NET Core backend:

### Replace mock calls with React Query hooks:

```ts
// Example: Fetch products
import { useQuery } from '@tanstack/react-query';

const { data: products, isLoading } = useQuery({
  queryKey: ['products', category],
  queryFn: () => fetch(`${import.meta.env.VITE_API_URL}/products?category=${category}`)
    .then(res => res.json()),
});
```

### Auth Headers

```ts
// Add JWT token to requests
const headers = {
  'Authorization': `Bearer ${useAuthStore.getState().token}`,
  'Content-Type': 'application/json',
};
```

### Expected Backend Endpoints

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/products` | List products (with filters) |
| `GET` | `/api/products/:id` | Single product |
| `GET` | `/api/categories` | List categories |
| `POST` | `/api/auth/login` | Customer login |
| `POST` | `/api/auth/register` | Customer register |
| `POST` | `/api/orders` | Place order |
| `GET` | `/api/orders/:id` | Order detail |
| `GET` | `/api/admin/dashboard` | Admin stats |
| `GET` | `/api/admin/orders` | Admin orders list |
| `GET` | `/api/admin/products` | Admin products list |
| `PUT` | `/api/admin/products/:id` | Update product |
| `GET` | `/api/admin/customers` | Admin customers list |
| `GET` | `/api/admin/statistics` | Sales statistics |

---

## Deployment

### Frontend → Vercel

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel --prod
```

**vercel.json** (for SPA routing):
```json
{
  "rewrites": [{ "source": "/(.*)", "destination": "/index.html" }]
}
```

### Backend → Railway

The ASP.NET Core backend (C#) deploys to Railway with PostgreSQL database also on Railway.

---

## Order Flow Summary

```
Customer browses products
        ↓
Adds items to Cart (Zustand)
        ↓
Opens Cart Drawer → "My Curation"
        ↓
Proceeds to Checkout (/checkout)
        ↓
Fills Delivery Info → Payment UI
        ↓
Clicks PLACE ORDER
        ↓
POST /api/orders → status: Pending
        ↓
Redirected to /order-confirmation/:id
        ↓
Admin sees order in /admin/orders
        ↓
Admin updates status: Pending → Confirmed → Processing → Shipped → Delivered
        ↓
Customer tracks from /account
```

---

## Key Design Decisions

| Decision | Reason |
|---|---|
| Mobile-first (max 430px) | All designs were mobile-optimized |
| Zustand over Redux | Simpler API, less boilerplate, built-in persist |
| React Query for API | Automatic caching, loading/error states, refetching |
| React Hook Form + Zod | Type-safe form validation |
| Recharts for admin | Lightweight, responsive charts with Tailwind-compatible styling |
| No CSS framework except Tailwind | Per project spec |
| Playfair Display + Inter + Cormorant | Luxury editorial feel matching Nişantaşı aesthetic |

---

## Component Quick Reference

| Component | Path | Description |
|---|---|---|
| `Navbar` | `components/common/Navbar.tsx` | Sticky nav + hamburger drawer + bottom nav |
| `Footer` | `components/common/Footer.tsx` | Dark charcoal footer |
| `AdminFooter` | `components/common/Footer.tsx` | Admin-specific footer |
| `ProductCard` | `components/common/ProductCard.tsx` | Product card + skeleton |
| `CartDrawer` | `components/common/CartDrawer.tsx` | Slide-in cart panel |

---

## License

Proprietary — LADY FASHION © 2024. All rights reserved.

---

*Crafted with elegance for the Aura de Nişantaşı experience.*
