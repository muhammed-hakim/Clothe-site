import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Settings, Camera, Lock, Bell } from 'lucide-react';
import { useAuthStore } from '../../store';
import toast from 'react-hot-toast';

export default function ProfilePage() {
  const { user, updateUser } = useAuthStore();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    fullName: user?.fullName ?? 'Leyla Demir',
    email: user?.email ?? 'leyla.demir@atelier.com',
    phone: user?.phone ?? '+90 532 000 00 00',
    currentPassword: '',
    newPassword: '',
    confirmNewPassword: '',
    newsletter: true,
    sms: false,
  });

  const handleInput = (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));

  const handleToggle = (field: 'newsletter' | 'sms') =>
    setForm((prev) => ({ ...prev, [field]: !prev[field] }));

  const handleSave = () => {
    updateUser({ fullName: form.fullName, email: form.email, phone: form.phone });
    toast.success('Profile updated successfully!');
    navigate('/account');
  };

  return (
    <div className="pb-28">
      {/* Header */}
      <div className="flex items-center justify-between px-4 pt-5 pb-4">
        <button
          onClick={() => navigate(-1)}
          className="w-9 h-9 flex items-center justify-center rounded-full bg-white shadow-sm"
        >
          <ArrowLeft size={18} className="text-charcoal" />
        </button>
        <p className="font-inter text-xs font-bold tracking-widest uppercase text-charcoal">
          PROFILE
        </p>
        <button className="w-9 h-9 flex items-center justify-center rounded-full bg-white shadow-sm">
          <Settings size={16} className="text-charcoal" />
        </button>
      </div>

      {/* Title */}
      <div className="px-4 mb-6 text-center">
        <h1 className="font-playfair text-2xl font-semibold text-charcoal mb-1">
          Edit Your Profile
        </h1>
        <p className="font-cormorant italic text-soft-gray text-sm">
          Manage your personal style and account settings.
        </p>
      </div>

      {/* Avatar */}
      <div className="flex flex-col items-center mb-7">
        <div className="relative">
          <div className="w-24 h-24 rounded-full overflow-hidden bg-rose-light ring-4 ring-rose-primary/20">
            {user?.avatar ? (
              <img src={user.avatar} alt="Profile" className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <img
                  src="https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=200&q=80"
                  alt="Profile"
                  className="w-full h-full object-cover"
                />
              </div>
            )}
          </div>
          {/* Camera button */}
          <button className="absolute bottom-0 right-0 w-8 h-8 bg-rose-dark rounded-full flex items-center justify-center shadow-md">
            <Camera size={14} className="text-white" />
          </button>
        </div>
        <p className="font-playfair text-base font-semibold text-charcoal mt-3">
          Atelier Member
        </p>
        <p className="text-[10px] tracking-widest uppercase text-soft-gray">
          PROFILE PHOTO
        </p>
        <p className="text-xs text-soft-gray text-center mt-1 max-w-xs leading-relaxed">
          Recommended: High-resolution JPG or PNG. Your photo helps us personalize your boutique experience.
        </p>
      </div>

      {/* Personal Information */}
      <div className="px-4 mb-5">
        <p className="text-[10px] font-bold tracking-widest uppercase text-charcoal text-center mb-4">
          PERSONAL INFORMATION
        </p>
        <div className="bg-white rounded-card shadow-card p-5 space-y-4">
          <div>
            <label className="input-label">FULL NAME</label>
            <input
              name="fullName"
              value={form.fullName}
              onChange={handleInput}
              className="input-field"
            />
          </div>
          <div>
            <label className="input-label">EMAIL ADDRESS</label>
            <input
              name="email"
              value={form.email}
              onChange={handleInput}
              type="email"
              className="input-field"
            />
          </div>
          <div>
            <label className="input-label">PHONE NUMBER</label>
            <input
              name="phone"
              value={form.phone}
              onChange={handleInput}
              type="tel"
              className="input-field"
            />
          </div>
        </div>
      </div>

      {/* Password & Security */}
      <div className="px-4 mb-5">
        <div className="bg-white rounded-card shadow-card p-5">
          <div className="flex items-center justify-between mb-4">
            <p className="text-[10px] font-bold tracking-widest uppercase text-charcoal">
              PASSWORD & SECURITY
            </p>
            <Lock size={16} className="text-soft-gray" />
          </div>
          <div className="space-y-4">
            <div>
              <label className="input-label">CURRENT PASSWORD</label>
              <input
                name="currentPassword"
                value={form.currentPassword}
                onChange={handleInput}
                type="password"
                placeholder="••••••••"
                className="input-field"
              />
            </div>
            <div>
              <label className="input-label">NEW PASSWORD</label>
              <input
                name="newPassword"
                value={form.newPassword}
                onChange={handleInput}
                type="password"
                placeholder=""
                className="input-field"
              />
            </div>
            <div>
              <label className="input-label">CONFIRM NEW PASSWORD</label>
              <input
                name="confirmNewPassword"
                value={form.confirmNewPassword}
                onChange={handleInput}
                type="password"
                placeholder=""
                className="input-field"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Preferences */}
      <div className="px-4 mb-6">
        <p className="text-[10px] font-bold tracking-widest uppercase text-charcoal text-center mb-4">
          PREFERENCES
        </p>
        <div className="bg-white rounded-card shadow-card overflow-hidden">
          {/* Newsletter */}
          <div className="flex items-start justify-between p-5 border-b border-gray-50">
            <div className="flex-1 pr-4">
              <p className="font-inter font-medium text-sm text-charcoal mb-0.5">
                Newsletter Subscription
              </p>
              <p className="text-xs text-soft-gray leading-relaxed">
                Receive weekly style edits and exclusive event invitations.
              </p>
            </div>
            <button
              onClick={() => handleToggle('newsletter')}
              className={`toggle flex-shrink-0 mt-0.5 ${form.newsletter ? 'on' : 'off'}`}
            >
              <span className="toggle-thumb" />
            </button>
          </div>

          {/* SMS */}
          <div className="flex items-start justify-between p-5">
            <div className="flex-1 pr-4">
              <p className="font-inter font-medium text-sm text-charcoal mb-0.5">
                SMS Notifications
              </p>
              <p className="text-xs text-soft-gray leading-relaxed">
                Get instant alerts about order delivery and flash arrivals.
              </p>
            </div>
            <button
              onClick={() => handleToggle('sms')}
              className={`toggle flex-shrink-0 mt-0.5 ${form.sms ? 'on' : 'off'}`}
            >
              <span className="toggle-thumb" />
            </button>
          </div>
        </div>
      </div>

      {/* Save Button */}
      <div className="px-4 space-y-3">
        <button onClick={handleSave} className="btn-primary w-full py-4 text-sm">
          SAVE CHANGES
        </button>
        <button
          onClick={() => navigate(-1)}
          className="w-full text-center text-xs font-medium tracking-widest uppercase text-soft-gray py-3 hover:text-charcoal transition-colors"
        >
          CANCEL
        </button>
      </div>

      {/* Bottom Nav Labels */}
      <div className="fixed bottom-0 left-0 right-0 max-w-[430px] mx-auto bg-white border-t border-gray-100 z-40">
        <div className="flex items-center justify-around py-2">
          {[
            { label: 'Shop', icon: '🛍' },
            { label: 'Search', icon: '🔍' },
            { label: 'Bag', icon: '👜' },
            { label: 'Saved', icon: '♡' },
            { label: 'Profile', icon: '👤', active: true },
          ].map((item) => (
            <div
              key={item.label}
              className={`flex flex-col items-center gap-0.5 px-2 py-1 ${
                item.active ? 'text-rose-dark' : 'text-soft-gray'
              }`}
            >
              <span className="text-lg">{item.icon}</span>
              <span className="text-[9px] tracking-wider uppercase">{item.label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
