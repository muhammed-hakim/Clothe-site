import React from 'react';
import ReactDOM from 'react-dom/client';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from 'react-hot-toast';
import App from './App';
import './styles/globals.css';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      retry: 1,
    },
  },
});

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <App />
      <Toaster
        position="top-right"
        toastOptions={{
          duration: 3000,
          style: {
            fontFamily: 'Inter, sans-serif',
            fontSize: '13px',
            borderRadius: '12px',
            background: '#2C2C2C',
            color: '#FAF7F5',
          },
          success: {
            iconTheme: {
              primary: '#E8A0B4',
              secondary: '#FAF7F5',
            },
          },
          error: {
            iconTheme: {
              primary: '#D4726A',
              secondary: '#FAF7F5',
            },
          },
        }}
      />
    </QueryClientProvider>
  </React.StrictMode>
);
