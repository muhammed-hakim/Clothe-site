import { Link } from 'react-router-dom';
import Footer from '../../components/common/Footer';

export default function AboutPage() {
  const values = [
    {
      icon: '✦',
      title: 'Craftsmanship',
      description: 'Every piece is hand-inspected by our master artisans in our Nişantaşı atelier before reaching you.',
    },
    {
      icon: '🌿',
      title: 'Sustainability',
      description: 'We use FSC-certified materials and pH-neutral packaging to preserve both your garment and our planet.',
    },
    {
      icon: '♀',
      title: 'Empowerment',
      description: 'LADY FASHION celebrates the modern woman — confident, elegant, and unapologetically herself.',
    },
  ];

  return (
    <div className="pb-20">
      {/* Hero */}
      <div className="relative h-72 overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=800&q=80"
          alt="Lady Fashion Atelier"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-charcoal/50" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-6">
          <p className="font-cormorant italic text-white/80 text-sm mb-2">Est. 2018, İstanbul</p>
          <h1 className="font-playfair text-4xl font-bold text-white leading-tight">
            The Art of Elegance
          </h1>
        </div>
      </div>

      {/* Story */}
      <div className="px-4 py-8">
        <div className="bg-white rounded-card shadow-card p-6 mb-6">
          <p className="text-[10px] tracking-widest uppercase text-rose-dark font-medium mb-2">
            A STORY FROM NİŞANTAŞI
          </p>
          <h2 className="font-playfair text-2xl font-semibold text-charcoal mb-4">
            Born from the Golden Streets of Istanbul
          </h2>
          <p className="text-sm text-soft-gray leading-relaxed mb-3">
            LADY FASHION was born in the heart of Nişantaşı — Istanbul's premier fashion district — where East meets West and tradition embraces modernity. Our founder, Leyla Demir, envisioned a space where Turkish artisanship could meet European aesthetic sensibility.
          </p>
          <p className="text-sm text-soft-gray leading-relaxed">
            Every collection is a dialogue between the shimmering waters of the strait and the fluid light of Turkish summer. Our pieces are selected for the woman who values timeless elegance over fleeting trends.
          </p>
        </div>

        {/* Values */}
        <div className="mb-6">
          <h2 className="font-playfair text-2xl font-semibold text-charcoal text-center mb-5">
            Our Guiding Pillars
          </h2>
          <div className="space-y-4">
            {values.map((value) => (
              <div key={value.title} className="bg-white rounded-card shadow-card p-5 flex gap-4">
                <div className="w-10 h-10 rounded-full bg-rose-light flex items-center justify-center flex-shrink-0 text-rose-dark text-lg">
                  {value.icon}
                </div>
                <div>
                  <h3 className="font-playfair text-base font-semibold text-charcoal mb-1">
                    {value.title}
                  </h3>
                  <p className="text-xs text-soft-gray leading-relaxed">
                    {value.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Atelier Image */}
        <div className="rounded-card overflow-hidden mb-6 h-52">
          <img
            src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&q=80"
            alt="Atelier hands"
            className="w-full h-full object-cover"
          />
        </div>

        {/* The Hands */}
        <div className="bg-cream rounded-card p-6 mb-6">
          <h2 className="font-playfair text-xl font-semibold text-charcoal mb-3">
            The Hands Behind the Art
          </h2>
          <p className="text-sm text-soft-gray leading-relaxed">
            Our master artisans bring decades of expertise to each piece. From the initial drape to the final stitch, every garment is a testament to the artisan's hand and the soul of Istanbul's fashion heritage.
          </p>
        </div>

        {/* Founder Quote */}
        <div className="text-center px-4 mb-8">
          <p className="font-cormorant italic text-xl text-charcoal leading-relaxed mb-3">
            "Fashion is not just about clothes, it is about the story you tell when you walk into the room."
          </p>
          <p className="text-xs text-soft-gray tracking-widest uppercase font-medium">
            — LEYLA DEMİR, FOUNDER
          </p>
        </div>

        {/* CTA */}
        <div className="text-center">
          <Link to="/shop" className="btn-primary text-xs px-10 py-3.5">
            EXPLORE THE COLLECTION
          </Link>
        </div>
      </div>

      <Footer />
    </div>
  );
}
